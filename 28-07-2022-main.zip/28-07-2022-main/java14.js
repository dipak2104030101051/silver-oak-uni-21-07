//* * ASSIGHMENT * *//
document.write("Assighment");
let x = 10;
x += 5;
document.write("<br><b> + = :</b><br>",x);

let a = 10;
a -= 5;
document.write("<br><b> - = :</b><br>",a);

let b = 10;
b *= 5;
document.write("<br><b> * = :</b><br>",b);

let c = 10;
c /= 5;
document.write("<br><b> + = :</b><br>",c);

let d = 10;
d %= 5;
document.write("<br><b> % = :</b><br>",x);



