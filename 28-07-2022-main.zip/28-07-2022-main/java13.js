//* * ARITHMETIC OPERATOR * *//
document.write("Arithmetic");
let x = 5,y = 5;
let z = x + y;
document.write(z);

let a = 3;
let b = (100 + 50) * a;
document.write("<br><b>Addition</b><br>",b);

let e = 5;
let f = 2;
let g = e - f;
document.write("<br><b>Subtracting:</b><br>",g);

let k = 5;
let i = 2;
let h = k * i;
document.write("<br><b> Multiplying:</b><br>",h);


let l = 5;
let m = 2;
let n = l / m;
document.write("<br><b> Dividing: </b><br>",n);


let a1 = 5;
let b1 = 2;
let c1 = a1 % b1;
document.write("<br><b>Remainder:</b><br>",c1);

let x1 = 5;
x1++;
let z1 = x1;
document.write("<br><b> Increment:</b><br> ",z1);


let d1=5;
d2= d1** 2;
document.write("<br><b> Exponentiation:</b><br>",d2);
